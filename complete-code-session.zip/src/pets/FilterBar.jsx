// Filter Component - Shows filter options
export default function FilterBar({ showFavorites, onFilterChange }) {
  return (
    <div className="filter-bar">
      <h3>View:</h3>
      <button
        className={`filter-btn ${!showFavorites ? 'active' : ''}`}
        onClick={() => onFilterChange(false)}
      >
        All Pets
      </button>
      <button
        className={`filter-btn ${showFavorites ? 'active' : ''}`}
        onClick={() => onFilterChange(true)}
      >
        Favorites Only
      </button>
    </div>
  );
}
