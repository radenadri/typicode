import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';

import PetApp from './pets/PetApp';
import MainIDCard from './exercise/MainIDCard';

import './index.css';

createRoot(document.getElementById('root')).render(
  <StrictMode>
    <PetApp />
  </StrictMode>
);
