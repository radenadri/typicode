export default function NoPetFound(showFavorites) {
  return (
    <div className="no-pets">
      <h3>No pets found!</h3>
      <p>
        {showFavorites
          ? "You haven't favorited any available pets yet. Browse all pets to find your favorites!"
          : 'All pets have been adopted! 🎉'}
      </p>
    </div>
  );
}
