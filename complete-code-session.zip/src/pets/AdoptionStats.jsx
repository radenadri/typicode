// AdoptionStats Component - Shows statistics
export default function AdoptionStats({
  totalPets,
  adoptedCount,
  favoritedCount,
}) {
  const availablePets = totalPets - adoptedCount;

  return (
    <div className="stats-container">
      <h2>Fluffy Stats</h2>
      <div className="stats-grid">
        <div className="stat-card">
          <span className="stat-number">{totalPets}</span>
          <span className="stat-label">Total Pets</span>
        </div>
        <div className="stat-card">
          <span className="stat-number">{availablePets}</span>
          <span className="stat-label">Available</span>
        </div>
        <div className="stat-card">
          <span className="stat-number">{adoptedCount}</span>
          <span className="stat-label">Adopted</span>
        </div>
        <div className="stat-card">
          <span className="stat-number">{favoritedCount}</span>
          <span className="stat-label">Favorited</span>
        </div>
      </div>
    </div>
  );
}
