import { useState } from 'react';

export default function Greeting() {
  const [name, setName] = useState(''); // default value that used on initial render
  const [age, setAge] = useState(1);
  const [showText, setShowText] = useState(true);

  return (
    <div>
      <div>
        <button onClick={() => setShowText(!showText)}>
          {showText ? 'Hide' : 'Show'}
        </button>
        {showText && (
          <h1>
            Hello, {name || 'stranger'} and i am {age} years old
          </h1>
        )}
        {showText && (
          <>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
            />
            <br />
            <input
              type="number"
              value={age}
              onChange={(e) => setAge(e.target.value)}
            />
          </>
        )}
      </div>
    </div>
  );
}
