export default function InputField(props) {
  return (
    <div>
      <label htmlFor={props.label}>{props.label}</label>
      <br />
      <input
        id={props.label}
        type="text"
        value={props.value}
        onChange={props.setValue}
      />
    </div>
  );
}
