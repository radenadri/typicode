// PetCard Component - Displays individual pet information
export default function PetCard({
  pet,
  onFavorite,
  onAdopt,
  isFavorited,
  isAdopted,
}) {
  return (
    <div className={`pet-card ${isAdopted ? 'adopted' : ''}`}>
      <div className="pet-image">{pet.image}</div>
      <div className="pet-info">
        <h3 className="pet-name">
          {pet.name}
          {isFavorited && <span className="heart">❤️</span>}
        </h3>
        <p className="pet-details">
          {pet.type} • {pet.age} years old
        </p>
        <p className="pet-description">{pet.description}</p>

        <div className="pet-actions">
          <button
            className={`favorite-btn ${isFavorited ? 'favorited' : ''}`}
            onClick={() => onFavorite(pet.id)}
            disabled={isAdopted}
          >
            {isFavorited ? '💖 Favorited' : '🤍 Favorite'}
          </button>

          <button
            className={`adopt-btn ${isAdopted ? 'adopted' : ''}`}
            onClick={() => onAdopt(pet.id)}
            disabled={isAdopted}
          >
            {isAdopted ? '✅ Adopted' : '🏠 Adopt Me'}
          </button>
        </div>

        {isAdopted && <div className="adopted-badge">ADOPTED!</div>}
      </div>
    </div>
  );
}
