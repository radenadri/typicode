import { useState } from 'react';

import IDCardApp from './IDCardApp';
import InputField from './InputField';

export default function MainIDCard() {
  const [name, setName] = useState('');
  const [number, setNumber] = useState('');
  const [position, setPosition] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');

  return (
    <>
      <IDCardApp
        name={name || 'stranger'}
        number={number || '000000'}
        position={position || 'unknown'}
        email={email || 'unknown'}
        phone={phone || 'unknown'}
      />
      <br />
      <div className="form">
        <InputField
          label="Name"
          value={name}
          setValue={(e) => setName(e.target.value)}
        />
        <InputField
          label="Number"
          value={number}
          setValue={(e) => setNumber(e.target.value)}
        />
        <InputField
          label="Position"
          value={position}
          setValue={(e) => setPosition(e.target.value)}
        />
        <InputField
          label="Email"
          value={email}
          setValue={(e) => setEmail(e.target.value)}
        />
        <InputField
          label="Phone"
          value={phone}
          setValue={(e) => setPhone(e.target.value)}
        />
      </div>
    </>
  );
}
