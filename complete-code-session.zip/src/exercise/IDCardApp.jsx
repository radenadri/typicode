import React from 'react';

import './IDCardApp.css';

export default function IDCardApp(props) {
  return (
    <div className="id-card">
      <div className="id-card-header">Identity Card</div>

      <div className="id-card-content">
        <div className="id-card-photo">🐱</div>

        <div className="id-card-info">
          <InfoItem label="Name" value={props.name} />
          <InfoItem label="ID Number" value={props.number} />
          <InfoItem label="Position" value={props.position} />
          <InfoItem label="Email" value={props.email} />
          <InfoItem label="Phone" value={props.phone} />
        </div>
      </div>
    </div>
  );
}

function InfoItem(props) {
  return (
    <div className="info-item">
      <div className="info-label">{props.label}</div>
      <div className="info-value">{props.value}</div>
    </div>
  );
}
