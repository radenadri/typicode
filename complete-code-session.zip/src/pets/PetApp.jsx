import React, { useState } from 'react';

import AdoptionStats from './AdoptionStats';
import FilterBar from './FilterBar';
import PetCard from './PetCard';
import NoPetFound from './NoPetFound';

import './PetApp.css';

// Sample pet data
const initialPets = [
  {
    id: 1,
    name: 'Whiskers',
    type: 'Cat',
    age: 2,
    image: '🐱',
    description: 'Calm and affectionate tabby cat',
  },
  {
    id: 2,
    name: 'Luna',
    type: 'Cat',
    age: 1,
    image: '🐈',
    description: 'Playful and curious kitten',
  },
];

// Main App Component
export default function PetApp() {
  // State for tracking favorites and adoptions
  const [favorites, setFavorites] = useState(new Set());
  const [adopted, setAdopted] = useState(new Set());
  const [showFavorites, setShowFavorites] = useState(false);

  // Handle favoriting a pet
  const handleFavorite = (petId) => {
    setFavorites((prev) => {
      const newFavorites = new Set(prev);
      if (newFavorites.has(petId)) {
        newFavorites.delete(petId);
      } else {
        newFavorites.add(petId);
      }
      return newFavorites;
    });
  };

  // Handle adopting a pet
  const handleAdopt = (petId) => {
    setAdopted((prev) => new Set([...prev, petId]));

    // Remove from favorites when adopted
    setFavorites((prev) => {
      const newFavorites = new Set(prev);
      newFavorites.delete(petId);

      return newFavorites;
    });
  };

  // Filter pets based on current filter
  const filteredPets = showFavorites
    ? initialPets.filter((pet) => favorites.has(pet.id) && !adopted.has(pet.id))
    : initialPets;

  return (
    <div className="app">
      <AdoptionStats
        totalPets={initialPets.length}
        adoptedCount={adopted.size}
        favoritedCount={favorites.size}
      />

      <FilterBar
        showFavorites={showFavorites}
        onFilterChange={setShowFavorites}
      />

      <main className="pets-container">
        {filteredPets.length === 0 ? (
          <NoPetFound showFavorites={showFavorites} />
        ) : (
          <div className="pets-grid">
            {filteredPets.map((pet) => (
              <PetCard
                key={pet.id}
                pet={pet}
                onFavorite={handleFavorite}
                onAdopt={handleAdopt}
                isFavorited={favorites.has(pet.id)}
                isAdopted={adopted.has(pet.id)}
              />
            ))}
          </div>
        )}
      </main>
    </div>
  );
}
